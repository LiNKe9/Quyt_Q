    CONFIG = {
    titleWeb: "Nấm lùn cute🍄",
    introTitle: 'Chào mừng Nấm lùn🍄 iu cụa toi',
    introDesc: `Đi Vũng Tàu
    Nhớ tui chứ gì tui biết mà =))
    Trả lời câu hỏi ii`,
    btnIntro: 'Gét gô',
    title: 'Về với anh điiiii',
    desc: 'Không chịu buộc chịu',
    btnYes: 'Đi 6 ngày 6 đêm, mẹ chửi hong về, ba gọi không về, Gét gô',
    btnNo: 'Không nha chêeeee :3',
    question: 'Lần này không bịp đâu hỏi thật đấy',
    btnReply: 'Gửi cho Tlinh nho hohoo =))',
    reply: 'Về với anh cháy banh cái vũng tàu',
    mess: 'Anh biết mà xăng đổ đầy bình rồi, :)) cháy phố Vũng Tàu thôi',
    messDesc: 'Xong về nhà em quẫy tiếp :))) nhá',
    btnAccept: 'Okiiiii lun gét gô <3',
    messLink: 'https://www.facebook.com/messages/t/100040770521015' //link mess của các bạn. VD: https://www.facebook.com/messages/t/100014188333536
}
